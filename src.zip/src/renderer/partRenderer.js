/**
 * PartRenderer — manages one VAO per scene part.
 *
 * VAO layout (interleaved):
 *   attribute 0  a_position  vec2  (bytes 0-7)
 *   attribute 1  a_uv        vec2  (bytes 8-15)
 *   stride = 16 bytes per vertex
 *
 * Index buffer holds triangle indices as Uint16Array (or Uint32Array for >65k verts).
 */

const BYTES_PER_VERTEX = 16; // 4 floats × 4 bytes

export class PartRenderer {
  /**
   * @param {WebGL2RenderingContext} gl
   * @param {WebGLProgram}           meshProgram
   * @param {WebGLProgram}           wireProgram
   */
  constructor(gl, meshProgram, wireProgram) {
    this.gl = gl;
    this.meshProgram = meshProgram;
    this.wireProgram = wireProgram;
    /** @type {Map<string, PartGPUState>} */
    this._parts = new Map();
  }

  // ── Upload ─────────────────────────────────────────────────────────────────

  /**
   * Full mesh upload — call when mesh topology changes (new triangulation).
   * @param {string} partId
   * @param {{ vertices: Array<{x,y,uvX?,uvY?}>, uvs: Float32Array, triangles: Array<[number,number,number]> }} mesh
   */
  uploadMesh(partId, mesh) {
    const { gl } = this;
    const { vertices, uvs, triangles } = mesh;
    const n = vertices.length;

    // Build interleaved [x, y, u, v] buffer
    const vertexData = new Float32Array(n * 4);
    for (let i = 0; i < n; i++) {
      vertexData[i * 4]     = vertices[i].x;
      vertexData[i * 4 + 1] = vertices[i].y;
      vertexData[i * 4 + 2] = uvs[i * 2];
      vertexData[i * 4 + 3] = uvs[i * 2 + 1];
    }

    // Flat index array
    const indexData = new Uint16Array(triangles.length * 3);
    for (let i = 0; i < triangles.length; i++) {
      indexData[i * 3]     = triangles[i][0];
      indexData[i * 3 + 1] = triangles[i][1];
      indexData[i * 3 + 2] = triangles[i][2];
    }

    // Reuse or create GPU state
    let state = this._parts.get(partId);
    if (!state) {
      state = {
        vao:        null,
        vbo:        null,
        ibo:        null,
        edgeIbo:    null,
        texture:    null,
        indexCount: 0,
        edgeIndexCount: 0,
        vertCount:  0,
      };
      this._parts.set(partId, state);
    }

    if (!state.vao) state.vao = gl.createVertexArray();
    if (!state.vbo) state.vbo = gl.createBuffer();
    if (!state.ibo) state.ibo = gl.createBuffer();
    if (!state.edgeIbo) state.edgeIbo = gl.createBuffer();

    state.indexCount = indexData.length;
    state.vertCount  = n;

    // Bind VAO and upload buffers
    gl.bindVertexArray(state.vao);

    gl.bindBuffer(gl.ARRAY_BUFFER, state.vbo);
    gl.bufferData(gl.ARRAY_BUFFER, vertexData, gl.DYNAMIC_DRAW);

    // a_position: location 0
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, BYTES_PER_VERTEX, 0);

    // a_uv: location 1
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, 2, gl.FLOAT, false, BYTES_PER_VERTEX, 8);

    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, state.ibo);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indexData, gl.STATIC_DRAW);

    // Edge indices
    if (mesh.edgeIndices) {
      const edgeData = new Uint16Array(mesh.edgeIndices);
      state.edgeIndexCount = edgeData.length;
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, state.edgeIbo);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, edgeData, gl.STATIC_DRAW);
    } else {
      state.edgeIndexCount = 0;
    }

    // Ensure the main triangle ibo is bound to the VAO for the textured mesh pass
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, state.ibo);

    gl.bindVertexArray(null);
  }

  /**
   * Positions-only re-upload — hot path for vertex drag.
   * Does not change UVs or topology.
   * @param {string}                         partId
   * @param {Array<{x:number,y:number}>}     vertices
   * @param {Float32Array}                   uvs
   */
  uploadPositions(partId, vertices, uvs) {
    const { gl } = this;
    const state = this._parts.get(partId);
    if (!state) return;

    const n = vertices.length;
    const vertexData = new Float32Array(n * 4);
    for (let i = 0; i < n; i++) {
      vertexData[i * 4]     = vertices[i].x;
      vertexData[i * 4 + 1] = vertices[i].y;
      vertexData[i * 4 + 2] = uvs[i * 2];
      vertexData[i * 4 + 3] = uvs[i * 2 + 1];
    }

    gl.bindBuffer(gl.ARRAY_BUFFER, state.vbo);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, vertexData);
  }

  /**
   * Upload (or replace) the texture for a part.
   * @param {string}                         partId
   * @param {HTMLImageElement|ImageBitmap|ImageData} source
   */
  uploadTexture(partId, source) {
    const { gl } = this;
    let state = this._parts.get(partId);
    if (!state) {
      // Create a stub state that can hold the texture before mesh arrives
      state = { vao: null, vbo: null, ibo: null, edgeIbo: null, texture: null, indexCount: 0, edgeIndexCount: 0, vertCount: 0, texWidth: 0, texHeight: 0 };
      this._parts.set(partId, state);
    }

    if (state.texture) gl.deleteTexture(state.texture);

    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    gl.generateMipmap(gl.TEXTURE_2D);

    state.texture = tex;
    state.texWidth = source.width;
    state.texHeight = source.height;
  }

  // ── Draw ──────────────────────────────────────────────────────────────────

  /**
   * Draw one part's mesh (textured).
   * Caller must have already called gl.useProgram(meshProgram).
   * @param {string}       partId
   * @param {Float32Array} mvp      - 9-element column-major 3×3 matrix
   * @param {number}       opacity
   * @param {WebGLUniformLocation} uMvp
   * @param {WebGLUniformLocation} uTexture
   * @param {WebGLUniformLocation} uOpacity
   */
  drawPart(partId, mvp, opacity, uMvp, uTexture, uOpacity) {
    const { gl } = this;
    const state = this._parts.get(partId);
    if (!state || !state.vao || !state.texture || state.indexCount === 0) return;

    gl.uniformMatrix3fv(uMvp, false, mvp);
    gl.uniform1f(uOpacity, opacity);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, state.texture);
    gl.uniform1i(uTexture, 0);

    gl.bindVertexArray(state.vao);
    gl.drawElements(gl.TRIANGLES, state.indexCount, gl.UNSIGNED_SHORT, 0);
    gl.bindVertexArray(null);
  }

  /**
   * Draw part wireframe for selection overlay.
   * @param {string}       partId
   * @param {Float32Array} mvp
   * @param {WebGLUniformLocation} uMvp
   * @param {WebGLUniformLocation} uColor
   */
  drawWireframe(partId, mvp, uMvp, uColor) {
    const { gl } = this;
    const state = this._parts.get(partId);
    if (!state || !state.vao || state.indexCount === 0) return;

    gl.uniformMatrix3fv(uMvp, false, mvp);
    gl.uniform4f(uColor, 0.2, 0.9, 0.5, 0.6); // translucent green

    gl.bindVertexArray(state.vao);
    // Draw as lines — loop over each triangle
    gl.drawElements(gl.LINES, state.indexCount, gl.UNSIGNED_SHORT, 0);
    gl.bindVertexArray(null);
  }

  /**
   * Draw the boundary edge loop as a LINE_LOOP.
   * Caller must have already called gl.useProgram(wireProgram).
   * @param {string} partId
   * @param {Float32Array} mvp
   * @param {WebGLUniformLocation} uMvp
   * @param {WebGLUniformLocation} uColor
   */
  drawEdgeOutline(partId, mvp, uMvp) {
    const { gl } = this;
    const state = this._parts.get(partId);
    if (!state || !state.vao || state.edgeIndexCount === 0) return;

    gl.uniformMatrix3fv(uMvp, false, mvp);

    gl.bindVertexArray(state.vao);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, state.edgeIbo);
    gl.drawElements(gl.LINE_LOOP, state.edgeIndexCount, gl.UNSIGNED_SHORT, 0);
    // Restore triangle IBO
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, state.ibo);
    gl.bindVertexArray(null);
  }

  /**
   * Draw vertices as points.
   * @param {string} partId
   * @param {Float32Array} mvp
   * @param {WebGLUniformLocation} uMvp
   * @param {WebGLUniformLocation} uColor
   */
  drawVertices(partId, mvp, uMvp, uColor) {
    const { gl } = this;
    const state = this._parts.get(partId);
    if (!state || !state.vao || state.vertCount === 0) return;

    gl.bindVertexArray(state.vao);

    // 1. Draw all vertices (Density points - dark blue/purple)
    gl.uniformMatrix3fv(uMvp, false, mvp);
    gl.uniform4f(uColor, 0.4, 0.2, 0.8, 0.8); // Purple for density
    gl.drawArrays(gl.POINTS, 0, state.vertCount);

    // 2. Draw edge vertices (Bright green)
    if (state.edgeIndexCount > 0) {
      gl.uniform4f(uColor, 0.2, 0.9, 0.1, 1.0); // Bright green for edges
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, state.edgeIbo);
      gl.drawElements(gl.POINTS, state.edgeIndexCount, gl.UNSIGNED_SHORT, 0);
      
      // Restore standard triangle index buffer binding for this VAO
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, state.ibo);
    }

    gl.bindVertexArray(null);
  }

  /**
   * Draw a flat textured quad for parts without a mesh.
   * Used as fallback when mesh is null.
   * @param {string}       partId
   * @param {Float32Array} mvp
   * @param {number}       opacity
   * @param {WebGLUniformLocation} uMvp
   * @param {WebGLUniformLocation} uTexture
   * @param {WebGLUniformLocation} uOpacity
   */
  drawFlatPart(partId, mvp, opacity, uMvp, uTexture, uOpacity) {
    const { gl } = this;
    const state = this._parts.get(partId);
    if (!state || !state.texture || state.texWidth === 0 || state.texHeight === 0) return;

    // Create or reuse flat quad VAO for this part
    if (!state.flatVao) {
      const w = state.texWidth;
      const h = state.texHeight;

      // 4 vertices: corners of the texture, with UV mapping
      const vertices = new Float32Array([
        0,     0,     0, 0, // bottom-left
        w,     0,     1, 0, // bottom-right
        w,     h,     1, 1, // top-right
        0,     h,     0, 1, // top-left
      ]);

      const indices = new Uint16Array([0, 1, 2, 0, 2, 3]); // 2 triangles

      state.flatVao = gl.createVertexArray();
      state.flatVbo = gl.createBuffer();
      state.flatIbo = gl.createBuffer();

      gl.bindVertexArray(state.flatVao);
      gl.bindBuffer(gl.ARRAY_BUFFER, state.flatVbo);
      gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

      // a_position
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 16, 0);

      // a_uv
      gl.enableVertexAttribArray(1);
      gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 16, 8);

      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, state.flatIbo);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW);

      gl.bindVertexArray(null);

      state.flatIndexCount = indices.length;
    }

    gl.uniformMatrix3fv(uMvp, false, mvp);
    gl.uniform1f(uOpacity, opacity);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, state.texture);
    gl.uniform1i(uTexture, 0);

    gl.bindVertexArray(state.flatVao);
    gl.drawElements(gl.TRIANGLES, state.flatIndexCount, gl.UNSIGNED_SHORT, 0);
    gl.bindVertexArray(null);
  }

  // ── Lifecycle ─────────────────────────────────────────────────────────────

  /**
   * Clear mesh GPU resources for a part (but keep texture and flat quad).
   * Used when deleting/disabling a mesh.
   * @param {string} partId
   */
  clearMesh(partId) {
    const { gl } = this;
    const state = this._parts.get(partId);
    if (!state) return;
    if (state.vao)     gl.deleteVertexArray(state.vao);
    if (state.vbo)     gl.deleteBuffer(state.vbo);
    if (state.ibo)     gl.deleteBuffer(state.ibo);
    if (state.edgeIbo) gl.deleteBuffer(state.edgeIbo);
    state.vao = null;
    state.vbo = null;
    state.ibo = null;
    state.edgeIbo = null;
    state.indexCount = 0;
    state.edgeIndexCount = 0;
    state.vertCount = 0;
  }

  /**
   * Destroy GPU resources for a part.
   * @param {string} partId
   */
  destroyPart(partId) {
    const { gl } = this;
    const state = this._parts.get(partId);
    if (!state) return;
    if (state.vao)     gl.deleteVertexArray(state.vao);
    if (state.vbo)     gl.deleteBuffer(state.vbo);
    if (state.ibo)     gl.deleteBuffer(state.ibo);
    if (state.edgeIbo) gl.deleteBuffer(state.edgeIbo);
    if (state.flatVao) gl.deleteVertexArray(state.flatVao);
    if (state.flatVbo) gl.deleteBuffer(state.flatVbo);
    if (state.flatIbo) gl.deleteBuffer(state.flatIbo);
    if (state.texture) gl.deleteTexture(state.texture);
    this._parts.delete(partId);
  }

  destroyAll() {
    for (const id of this._parts.keys()) this.destroyPart(id);
  }
}
